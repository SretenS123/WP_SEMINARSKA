package com.example.seminarksa_wp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeminarksaWpApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.example.seminarksa_wp.model.enumerations;

import lombok.Data;


public enum EventType {
    BAR,
    NIGHTCLUB,
    PARTY,
    LIVE_MUSIC,
    CONCERT,
    THEATRE,
    CINEMA,
    SHOW
}

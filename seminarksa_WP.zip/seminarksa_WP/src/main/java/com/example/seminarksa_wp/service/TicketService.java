package com.example.seminarksa_wp.service;

import com.example.seminarksa_wp.model.Event;
import com.example.seminarksa_wp.model.Ticket;
import com.example.seminarksa_wp.model.User;

import java.util.List;
import java.util.Optional;

public interface TicketService {
    List<Ticket> findAll();

    List<Ticket> findAllByUser(Long userId);

    Optional<Ticket> findById(Long id);


    Ticket create(Double price, Long eventId, Long userId,Integer quantity);

    Ticket edit(Long id,Double price, Long eventId, Long userId,Integer quantity);

    void deleteById(Long id);

}

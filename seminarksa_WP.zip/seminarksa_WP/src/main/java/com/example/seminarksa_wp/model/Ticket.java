package com.example.seminarksa_wp.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Integer quantity;

    private Double price;
    @ManyToOne
    private Event event;
    @ManyToOne
    private User user;

    public Ticket() {
    }

    public Ticket(Double price, Event event, User user,Integer quantity) {
        this.price = price;
        this.event = event;
        this.user = user;
        this.quantity = quantity;
    }
}

package com.example.seminarksa_wp.model.enumerations;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}
